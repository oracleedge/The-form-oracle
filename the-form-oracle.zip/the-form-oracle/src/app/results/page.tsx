import Link from "next/link";

export default function ResultsPage() {
  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-12">
      <h1 className="text-3xl sm:text-4xl font-bold mb-2">Results & Record</h1>
      <p className="text-[var(--muted)] mb-10">
        Every tip is logged. No hidden losses. This is how we keep it honest.
      </p>

      {/* Stats overview */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-12">
        {[
          { label: "Tips Settled", value: "—" },
          { label: "Win Strike", value: "—" },
          { label: "Place Strike", value: "—" },
          { label: "ROI (flat $1)", value: "—" },
        ].map((stat) => (
          <div key={stat.label} className="card p-5 text-center">
            <div className="text-2xl sm:text-3xl font-bold text-[var(--accent)] mb-1">
              {stat.value}
            </div>
            <div className="text-sm text-[var(--muted)]">{stat.label}</div>
          </div>
        ))}
      </div>

      <div className="card p-8 text-center">
        <h2 className="text-xl font-semibold mb-3">
          Track record coming soon
        </h2>
        <p className="text-[var(--muted)] max-w-lg mx-auto mb-6">
          Once we start publishing live tips, every selection will appear here
          with the result, odds at the time of the tip, and running P/L. 
          Transparency is non-negotiable.
        </p>
        <Link
          href="/access"
          className="inline-flex items-center justify-center bg-[var(--accent)] hover:bg-[var(--accent-hover)] text-black font-medium px-6 py-2.5 rounded-lg transition-colors"
        >
          Join the Free Trial
        </Link>
      </div>

      <div className="mt-12 text-sm text-[var(--muted)] leading-relaxed max-w-2xl">
        <p className="mb-2 font-medium text-zinc-300">How we measure performance</p>
        <ul className="list-disc list-inside space-y-1">
          <li>All tips recorded with timestamp and available odds</li>
          <li>Settled at official starting price or best available at tip time</li>
          <li>Separate tracking for win, place and exotic strategies</li>
          <li>No deleted tips, no selective reporting</li>
        </ul>
      </div>
    </div>
  );
}