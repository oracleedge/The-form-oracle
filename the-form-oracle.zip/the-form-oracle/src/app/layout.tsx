import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import Link from "next/link";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "The Form Oracle | Australian Racing Intelligence",
  description:
    "Sharp, data-driven tips for thoroughbred, harness and greyhound racing. Win, place, exotics and quaddies — built for serious punters.",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html
      lang="en"
      className={`${geistSans.variable} ${geistMono.variable} h-full antialiased`}
    >
      <body className="min-h-full flex flex-col bg-[var(--background)] text-[var(--foreground)]">
        {/* Header */}
        <header className="border-b border-[var(--card-border)] bg-[var(--card)]/80 backdrop-blur sticky top-0 z-50">
          <div className="max-w-6xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">
            <Link href="/" className="flex items-center gap-2 group">
              <div className="w-8 h-8 rounded-lg bg-[var(--accent)] flex items-center justify-center font-bold text-black text-sm">
                FO
              </div>
              <span className="font-semibold text-lg tracking-tight group-hover:text-[var(--accent)] transition-colors">
                The Form Oracle
              </span>
            </Link>

            <nav className="hidden sm:flex items-center gap-6 text-sm">
              <Link
                href="/tips"
                className="text-[var(--muted)] hover:text-white transition-colors"
              >
                Today&apos;s Tips
              </Link>
              <Link
                href="/results"
                className="text-[var(--muted)] hover:text-white transition-colors"
              >
                Results
              </Link>
              <Link
                href="/access"
                className="bg-[var(--accent)] hover:bg-[var(--accent-hover)] text-black font-medium px-4 py-2 rounded-lg transition-colors"
              >
                Get Access
              </Link>
            </nav>

            {/* Mobile menu button placeholder */}
            <Link
              href="/access"
              className="sm:hidden bg-[var(--accent)] text-black font-medium px-3 py-1.5 rounded-lg text-sm"
            >
              Access
            </Link>
          </div>
        </header>

        <main className="flex-1">{children}</main>

        {/* Footer */}
        <footer className="border-t border-[var(--card-border)] mt-16">
          <div className="max-w-6xl mx-auto px-4 sm:px-6 py-10">
            <div className="flex flex-col sm:flex-row justify-between gap-6">
              <div>
                <div className="font-semibold text-lg mb-2">The Form Oracle</div>
                <p className="text-[var(--muted)] text-sm max-w-xs">
                  Australian racing intelligence with a bit of larrikin edge.
                  Thoroughbred, harness & greyhounds.
                </p>
              </div>
              <div className="text-sm text-[var(--muted)] space-y-1">
                <p>18+ only. Gamble responsibly.</p>
                <p>
                  <a
                    href="https://www.gambleaware.org.au"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="hover:text-white underline"
                  >
                    GambleAware
                  </a>{" "}
                  · 1800 858 858
                </p>
                <p className="pt-2">Tips for entertainment purposes only.</p>
              </div>
            </div>
            <div className="mt-8 pt-6 border-t border-[var(--card-border)] text-xs text-[var(--muted)]">
              © {new Date().getFullYear()} The Form Oracle. All rights reserved.
            </div>
          </div>
        </footer>
      </body>
    </html>
  );
}