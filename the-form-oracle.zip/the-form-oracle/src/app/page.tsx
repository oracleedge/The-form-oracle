import Link from "next/link";

export default function Home() {
  return (
    <div>
      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-[var(--accent)]/10 via-transparent to-transparent pointer-events-none" />
        <div className="max-w-6xl mx-auto px-4 sm:px-6 pt-16 pb-20 sm:pt-24 sm:pb-28">
          <div className="max-w-3xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[var(--card)] border border-[var(--card-border)] text-sm text-[var(--muted)] mb-6">
              <span className="w-2 h-2 rounded-full bg-[var(--accent)] animate-pulse" />
              Live Australian Racing Intelligence
            </div>

            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight leading-[1.1] mb-6">
              Sharp form.{" "}
              <span className="text-[var(--accent)]">Clear edge.</span>
              <br />
              No fluff.
            </h1>

            <p className="text-lg sm:text-xl text-[var(--muted)] max-w-2xl mb-8 leading-relaxed">
              The Form Oracle delivers data-backed tips across thoroughbred,
              harness and greyhound racing. Win bets, place, exotics and
              quaddies — built by a punter who actually does the hard yards.
            </p>

            <div className="flex flex-col sm:flex-row gap-4">
              <Link
                href="/access"
                className="inline-flex items-center justify-center bg-[var(--accent)] hover:bg-[var(--accent-hover)] text-black font-semibold px-8 py-3.5 rounded-xl transition-colors glow-accent"
              >
                Start Free Trial
              </Link>
              <Link
                href="/tips"
                className="inline-flex items-center justify-center border border-[var(--card-border)] hover:border-[var(--muted)] text-white font-medium px-8 py-3.5 rounded-xl transition-colors"
              >
                See Today&apos;s Tips
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* What you get */}
      <section className="max-w-6xl mx-auto px-4 sm:px-6 py-16">
        <h2 className="text-2xl sm:text-3xl font-bold mb-10 text-center">
          What you actually get
        </h2>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {[
            {
              title: "Win & Place Tips",
              desc: "Clear selections with the reasoning behind them — not just a number.",
            },
            {
              title: "Exotics & Quaddies",
              desc: "Structured exotic plays and quaddie legs when the shape is right.",
            },
            {
              title: "All Three Codes",
              desc: "Thoroughbred, harness and greyhounds. One place for the lot.",
            },
            {
              title: "Speed & Bias Notes",
              desc: "Track patterns, early speed and bias callouts that matter.",
            },
            {
              title: "Transparent Results",
              desc: "Every tip logged. No cherry-picking. See the real record.",
            },
            {
              title: "Built for Busy Punters",
              desc: "Straight to the point. No 20-page form guides you don’t have time for.",
            },
          ].map((item) => (
            <div
              key={item.title}
              className="card p-6 hover:border-[var(--accent)]/40 transition-colors"
            >
              <h3 className="font-semibold text-lg mb-2">{item.title}</h3>
              <p className="text-[var(--muted)] text-sm leading-relaxed">
                {item.desc}
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* Aussie character strip */}
      <section className="border-y border-[var(--card-border)] bg-[var(--card)]/50">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 py-14 text-center">
          <p className="text-xl sm:text-2xl font-medium max-w-2xl mx-auto leading-relaxed">
            “We don’t do miracle systems or guaranteed winners.
            <br />
            We do the hard yards, call it as we see it, and keep the record
            honest.”
          </p>
          <p className="mt-4 text-[var(--muted)]">— The Form Oracle</p>
        </div>
      </section>

      {/* CTA */}
      <section className="max-w-6xl mx-auto px-4 sm:px-6 py-20 text-center">
        <h2 className="text-3xl font-bold mb-4">Ready for a clearer edge?</h2>
        <p className="text-[var(--muted)] mb-8 max-w-lg mx-auto">
          Jump on the free trial and see the daily tips for yourself. No lock-in
          while you’re testing it.
        </p>
        <Link
          href="/access"
          className="inline-flex items-center justify-center bg-[var(--accent)] hover:bg-[var(--accent-hover)] text-black font-semibold px-10 py-4 rounded-xl transition-colors glow-accent"
        >
          Start Free Trial
        </Link>
      </section>
    </div>
  );
}