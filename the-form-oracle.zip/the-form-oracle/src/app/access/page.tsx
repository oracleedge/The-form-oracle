"use client";

import { useState } from "react";

export default function AccessPage() {
  const [email, setEmail] = useState("");
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // For now this just captures the email locally.
    // Later we connect to a free form service (Formspree / Getform) or email list.
    console.log("Email submitted:", email);
    setSubmitted(true);
  };

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-12">
      <div className="max-w-xl mx-auto">
        <div className="text-center mb-10">
          <h1 className="text-3xl sm:text-4xl font-bold mb-3">
            Start your free trial
          </h1>
          <p className="text-[var(--muted)]">
            Get full access to The Form Oracle tips for 7 days. No charge while
            you test it.
          </p>
        </div>

        <div className="card p-8">
          {!submitted ? (
            <>
              <div className="mb-6 space-y-3 text-sm">
                <div className="flex items-start gap-3">
                  <span className="text-[var(--accent)] mt-0.5">✓</span>
                  <span>Daily tips across thoroughbred, harness & greyhounds</span>
                </div>
                <div className="flex items-start gap-3">
                  <span className="text-[var(--accent)] mt-0.5">✓</span>
                  <span>Win, place, exotic and quaddie plays</span>
                </div>
                <div className="flex items-start gap-3">
                  <span className="text-[var(--accent)] mt-0.5">✓</span>
                  <span>Clear reasoning on every selection</span>
                </div>
                <div className="flex items-start gap-3">
                  <span className="text-[var(--accent)] mt-0.5">✓</span>
                  <span>Cancel anytime — no lock-in during the trial</span>
                </div>
              </div>

              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label
                    htmlFor="email"
                    className="block text-sm font-medium mb-1.5"
                  >
                    Email address
                  </label>
                  <input
                    id="email"
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="you@email.com"
                    className="w-full px-4 py-3 rounded-lg bg-[var(--background)] border border-[var(--card-border)] focus:border-[var(--accent)] focus:outline-none transition-colors"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full bg-[var(--accent)] hover:bg-[var(--accent-hover)] text-black font-semibold py-3.5 rounded-xl transition-colors"
                >
                  Start Free Trial
                </button>
              </form>

              <p className="mt-4 text-xs text-center text-[var(--muted)]">
                By continuing you agree this is for entertainment purposes only.
                18+ · Gamble responsibly.
              </p>
            </>
          ) : (
            <div className="text-center py-6">
              <div className="w-14 h-14 rounded-full bg-[var(--accent)]/20 flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl text-[var(--accent)]">✓</span>
              </div>
              <h2 className="text-xl font-semibold mb-2">You’re on the list</h2>
              <p className="text-[var(--muted)] mb-6">
                Thanks — we’ve got your email. Full trial access and the next
                steps will land in your inbox shortly.
              </p>
              <p className="text-sm text-[var(--muted)]">
                In the meantime you can still check the{" "}
                <a href="/tips" className="text-[var(--accent)] hover:underline">
                  sample tips
                </a>
                .
              </p>
            </div>
          )}
        </div>

        <div className="mt-10 text-center text-sm text-[var(--muted)]">
          <p>
            Questions? Just reply to the welcome email once it arrives.
          </p>
        </div>
      </div>
    </div>
  );
}