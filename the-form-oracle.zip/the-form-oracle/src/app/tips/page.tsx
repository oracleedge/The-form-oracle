import { tips, lastUpdated } from "@/data/tips";
import Link from "next/link";

export default function TipsPage() {
  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-12">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-10">
        <div>
          <h1 className="text-3xl sm:text-4xl font-bold mb-2">Today&apos;s Tips</h1>
          <p className="text-[var(--muted)]">
            Updated {lastUpdated}
          </p>
        </div>
        <Link
          href="/access"
          className="inline-flex items-center justify-center bg-[var(--accent)] hover:bg-[var(--accent-hover)] text-black font-medium px-5 py-2.5 rounded-lg transition-colors text-sm"
        >
          Unlock Full Access
        </Link>
      </div>

      {/* Code filters placeholder */}
      <div className="flex flex-wrap gap-2 mb-8">
        {["All", "Thoroughbred", "Harness", "Greyhound"].map((code) => (
          <button
            key={code}
            className={`px-4 py-1.5 rounded-full text-sm border transition-colors ${
              code === "All"
                ? "bg-[var(--accent)] text-black border-[var(--accent)]"
                : "border-[var(--card-border)] text-[var(--muted)] hover:border-[var(--muted)]"
            }`}
          >
            {code}
          </button>
        ))}
      </div>

      <div className="space-y-4">
        {tips.map((tip) => (
          <div
            key={tip.id}
            className="card p-5 sm:p-6 hover:border-[var(--accent)]/30 transition-colors"
          >
            <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
              <div className="flex-1">
                <div className="flex flex-wrap items-center gap-2 mb-2">
                  <span className="text-xs font-medium px-2 py-0.5 rounded bg-[var(--card-border)] text-[var(--muted)]">
                    {tip.code}
                  </span>
                  <span className="text-xs font-medium px-2 py-0.5 rounded bg-[var(--accent)]/20 text-[var(--accent)]">
                    {tip.type}
                  </span>
                  <span
                    className={`text-xs font-medium px-2 py-0.5 rounded ${
                      tip.confidence === "High"
                        ? "bg-green-500/20 text-green-400"
                        : tip.confidence === "Medium"
                        ? "bg-yellow-500/20 text-yellow-400"
                        : "bg-orange-500/20 text-orange-400"
                    }`}
                  >
                    {tip.confidence}
                  </span>
                </div>

                <div className="flex items-baseline gap-3 mb-1">
                  <h2 className="text-xl font-semibold">{tip.selection}</h2>
                  {tip.odds && (
                    <span className="text-[var(--gold)] font-medium">
                      {tip.odds}
                    </span>
                  )}
                </div>

                <p className="text-sm text-[var(--muted)] mb-3">
                  {tip.meeting} · {tip.race} · {tip.time}
                </p>

                <p className="text-sm leading-relaxed text-zinc-300">
                  {tip.reason}
                </p>
              </div>

              <div className="sm:text-right">
                <span
                  className={`inline-block text-xs font-medium px-2.5 py-1 rounded-full ${
                    tip.status === "Pending"
                      ? "bg-zinc-700 text-zinc-300"
                      : tip.status === "Won"
                      ? "bg-green-600 text-white"
                      : tip.status === "Placed"
                      ? "bg-blue-600 text-white"
                      : "bg-red-600/80 text-white"
                  }`}
                >
                  {tip.status}
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-12 text-center card p-8">
        <h3 className="text-xl font-semibold mb-2">
          This is a sample of what members see
        </h3>
        <p className="text-[var(--muted)] mb-6 max-w-md mx-auto">
          Full daily coverage across more meetings, exotic plays and the complete
          reasoning is available to members.
        </p>
        <Link
          href="/access"
          className="inline-flex items-center justify-center bg-[var(--accent)] hover:bg-[var(--accent-hover)] text-black font-semibold px-8 py-3 rounded-xl transition-colors"
        >
          Start Free Trial
        </Link>
      </div>
    </div>
  );
}