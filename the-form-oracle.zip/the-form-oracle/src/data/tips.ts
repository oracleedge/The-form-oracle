// Easy place to update daily tips.
// Just edit this file and redeploy (or we can make it load from a simple JSON later).

export type Tip = {
  id: string;
  meeting: string;
  race: string;
  time: string;
  code: "Thoroughbred" | "Harness" | "Greyhound";
  selection: string;
  type: "Win" | "Place" | "Each Way" | "Exacta" | "Quinella" | "Trifecta" | "First Four" | "Quaddie";
  odds?: string;
  confidence: "High" | "Medium" | "Speculative";
  reason: string;
  status: "Pending" | "Won" | "Placed" | "Lost" | "Void";
};

export const tips: Tip[] = [
  {
    id: "1",
    meeting: "Randwick",
    race: "Race 6",
    time: "3:45pm",
    code: "Thoroughbred",
    selection: "Example Runner",
    type: "Win",
    odds: "$4.20",
    confidence: "High",
    reason:
      "Strong closing sectionals last start, maps for a perfect sit off the speed. Track bias favours on-pacers today.",
    status: "Pending",
  },
  {
    id: "2",
    meeting: "Menangle",
    race: "Race 4",
    time: "7:12pm",
    code: "Harness",
    selection: "Example Pacer",
    type: "Win",
    odds: "$5.50",
    confidence: "Medium",
    reason:
      "Drawn to advantage, recent form progressive. Driver change looks a positive.",
    status: "Pending",
  },
  {
    id: "3",
    meeting: "The Gardens",
    race: "Race 8",
    time: "8:05pm",
    code: "Greyhound",
    selection: "Example Dog",
    type: "Win",
    odds: "$3.80",
    confidence: "High",
    reason:
      "Box 1 specialist at this trip. Early speed to hold the lead and control the race.",
    status: "Pending",
  },
];

export const lastUpdated = "31 Oct 2026 – 9:00am AEDT";