# The Form Oracle

Australian racing intelligence — thoroughbred, harness & greyhounds.

**Style:** Clean professional with a bit of Aussie larrikin character.  
**Goal:** Free to launch and run until money starts coming in.

---

## What’s included

- Professional landing page
- Today’s Tips page (easy to update)
- Results / Track Record page
- Free trial / email capture page
- Mobile-friendly design
- Responsible gambling messaging

---

## How to get this live for $0 (step-by-step)

### 1. Create a free GitHub account
Go to: https://github.com  
Sign up with your email.

### 2. Create a new repository
- Click the green “New” button
- Name it: `the-form-oracle`
- Leave it Public (easiest) or Private
- **Do not** tick “Add a README”
- Click “Create repository”

### 3. Upload the files
On the new empty repo page you’ll see an option to upload files.  
Drag the **entire contents** of this folder into GitHub (or use the upload button).

### 4. Deploy free on Vercel
1. Go to https://vercel.com
2. Sign up / log in with your **GitHub** account
3. Click “Add New…” → “Project”
4. Select the `the-form-oracle` repository
5. Leave every setting as default
6. Click **Deploy**

In under a minute you’ll get a live link like:  
`the-form-oracle.vercel.app`

That’s your website. Completely free.

---

## How to update daily tips (very simple)

1. Open the file: `src/data/tips.ts`
2. Change the example tips to your real ones (meeting, selection, reason, odds, confidence, etc.)
3. Save and push the change to GitHub
4. Vercel will automatically update the live site in 30–60 seconds

That’s the whole process while you’re running it free.

---

## Next steps once people start signing up

1. Connect a free form service (Formspree or Tally) so the emails actually land in your inbox
2. When you’re ready to charge: add Stripe for the paid plan after the free trial
3. Later: add real data feeds and more automation once the site is making money

---

## Important notes

- The tips currently on the site are **examples** so it looks real.
- Replace them with your own analysis as soon as you’re live.
- Keep the responsible gambling text — it’s required in Australia.
- You own 100% of this. No one else has access.

You’re ready to go.  
Let’s get The Form Oracle live.